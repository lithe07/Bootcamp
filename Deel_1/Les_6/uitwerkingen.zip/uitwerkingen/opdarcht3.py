leeftijd = 15

if leeftijd >= 16:
    print("gegeliciteerd, je mag je brommerrijbewijs halen.")
else:
    print("Helaas, je zult nog even moeten wachten")