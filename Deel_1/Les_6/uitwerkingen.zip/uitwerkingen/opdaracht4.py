a = 3
b = 5 
print(a < b)

c = 10
d = 7
print(c > d)

e = 9
f = 9
print(e <= f)

z = 8
x = 6
print(z >= x)

naam1 ='Lithe'
naam2 = 'osama'
print(naam1 == naam2)

naam3 = 'miko'
naam4 = 'miko'
print(naam3 == naam4)