banaan= 3
print(banaan * 3)

apple = 3.40   
druiven = 2.45  
bananen = 1.95
btw = apple / 100 * 9
btw1 = druiven / 100 * 9
print(btw1)
print(btw)