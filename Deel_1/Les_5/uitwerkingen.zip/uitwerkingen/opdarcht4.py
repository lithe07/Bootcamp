straal =float(         input('straal?')  ) 
pi = 3.14159

oppervlakte = straal * straal * pi 
omtrek = 2 + straal + pi 

print(oppervlakte)
print(omtrek)