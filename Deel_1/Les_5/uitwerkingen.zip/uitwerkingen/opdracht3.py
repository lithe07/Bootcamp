var1 = input('vul getal in') # comentaar 
var2 = input('vul getal in') # comentaar
var3 = input('vul getal in') # comentaar

gemiddelde =float(var1 + var2 + var3) / 3

print(gemiddelde)