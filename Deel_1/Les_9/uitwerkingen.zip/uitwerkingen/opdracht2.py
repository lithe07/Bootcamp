getal = int(input("welke getal?"))

if getal % 7 == 0 and getal % 11 == 0:
    print("dit getal is zonder rest deelbaar.")
else:
    print("dit getal in nietzonder rest deelbaar.")