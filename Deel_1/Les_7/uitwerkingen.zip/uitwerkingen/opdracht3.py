quotient = 0
dividend = 625
divisor = 25

while dividend >= divisor:
    dividend -= divisor
    quotient += 1
print("25 past", quotient, "keer in 625.")