for x in range(20):
    print("Ik ben hard op weg developer te worden!")
