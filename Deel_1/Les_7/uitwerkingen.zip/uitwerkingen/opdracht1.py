for i in range(1, 25):
    print(i) 

