bedrag = 10000
rente = (2.8/100) + 1
jaar = 0

while jaar < 15: 
    bedrag = bedrag * rente
    jaar += 1
print(bedrag)