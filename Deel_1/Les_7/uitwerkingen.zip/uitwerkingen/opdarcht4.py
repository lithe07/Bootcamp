quotient = 0
dividend = 625
divisor = 12

while dividend >= divisor:
    dividend -= divisor
    quotient += 1
print("12 past", quotient, "keer in 625.")