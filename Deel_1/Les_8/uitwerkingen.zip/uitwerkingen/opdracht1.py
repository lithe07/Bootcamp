cijfer = int(input("wat is je cijfer?"))

if cijfer == 10:
    print("uitmuntend")
elif cijfer == 9: 
    print("zeer goed")
elif cijfer == 8:
    print("goed")
elif cijfer == 7:
    print("ruim voldoende")
elif cijfer == 6:
    print("voldoende")
elif cijfer == 5:
    print("bijna voldoende")
elif cijfer == 4:
    print("onvoldoende")
elif cijfer == 3:
    print("gering")
elif cijfer == 2:
    print("slecht")
elif cijfer == 1:
    print("zeer slecht")
