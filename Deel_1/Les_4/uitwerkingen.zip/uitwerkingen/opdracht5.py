cijfer1 = 25
cijfer = 0
ruseltaat = cijfer / cijfer1
print(ruseltaat)