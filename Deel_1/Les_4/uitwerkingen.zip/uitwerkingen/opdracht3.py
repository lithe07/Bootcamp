name = 'lithe'
print('Hallo ' + name + ' ,ik leer nu programmeren.')