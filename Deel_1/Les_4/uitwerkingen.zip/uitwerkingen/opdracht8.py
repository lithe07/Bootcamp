a = 13
b = 625
resultaat = b // a
print(resultaat)