print( (431 / 100) * 100 )
# eingenlijk moest het antwoord als het zelfde getal maar hier krijgen we andere antwoord met de code 