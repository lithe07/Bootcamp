studenten = 21
collegegeld =  2314
ruseltaat = studenten * collegegeld
print(ruseltaat)


