name = '252'
print('Hallo ' + name + ' ,ik leer nu programmeren.')