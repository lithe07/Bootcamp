def vermeniguldig_van_getallen (a, b):
    resultaat = a * b 
    return resultaat

getal1 = 6
getal2 = 2
resultaat = vermeniguldig_van_getallen(getal1, getal2)
print(f"het product van {getal1} en {getal2} is {resultaat}")



