def som_van_getallen (a, b):
    resultaat = a + b
    return resultaat

getal1 = 5 
getal2 = 3

resultaat = som_van_getallen (getal1, getal2)
print(f"de som van {getal1} en {getal2} is {resultaat}")
