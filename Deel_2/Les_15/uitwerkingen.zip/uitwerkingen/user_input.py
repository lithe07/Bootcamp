def get_integer(Vraag):
    getal = int(input(Vraag))
    return getal

def get_float(prompt):
    getal1 = float(input(prompt))
    return getal1

def get_string(prompt):
    zin = str(input(prompt))
    return zin

def get_letter(prompt):
    while True:
        letter_input = input(prompt)
        if len(letter_input) == 1:
            return letter_input.upper()
        else:
            print("voer een letter in ya eri")