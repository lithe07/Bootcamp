naam = input("wat is u naam?")
leeftijd_str = input("wat is leeftijd?")

leeftijd = int(leeftijd_str)

leeftijd_over_5_jaar = leeftijd + 5

print(f"{naam}, over 5 jaar zul je {leeftijd_over_5_jaar} jaar oud zijn.")
