woord = input("voer een woord in:")

aantal_tekens = len(woord)

print(f"het woord is: {woord} en bestaat uit {aantal_tekens} tekens.")