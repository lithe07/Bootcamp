getal1_str = input("voer het eerste getal in:")
getal2_str = input("voer het tweede getal in:")

getal1 = float(getal1_str)
getal2 = float(getal2_str)

gemiddelde = (getal1 + getal2) / 2

print(f"het gemiddelde van {getal1} en {getal2} is {gemiddelde}")