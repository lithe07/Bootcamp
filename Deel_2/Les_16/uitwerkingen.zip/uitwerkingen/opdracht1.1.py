from user_input1 import *


leeftijd = get_integer("wat is je leeftijd? ")
print(leeftijd)

float1 = get_float("scshrijf een coma getal! ")
print(float1)

zin = get_string("schrijf een zin! ")
print(zin)

letter_input = get_letter("schrijf een letter in! ")
print(letter_input)