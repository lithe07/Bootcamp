getallen_lijst = []

for x in range (5):
    getal = int(input(f"voer getal {x+1} in:"))
    getallen_lijst.append(getal)

print(getallen_lijst)
print("De ingevoerde getalen")