worden_lijst = []

for i in range(5):
    worden = input("voer een woord in! ")
    worden_lijst.append(worden)


print(worden)
print(worden_lijst)
